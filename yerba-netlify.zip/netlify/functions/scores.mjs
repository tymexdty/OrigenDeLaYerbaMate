import { getStore } from "@netlify/blobs";

const QUESTIONS = 6;
const json = (d, s = 200) =>
  new Response(JSON.stringify(d), {
    status: s,
    headers: { "content-type": "application/json", "cache-control": "no-store" },
  });

export default async (req) => {
  const store = getStore("yerba-scores");

  if (req.method === "POST") {
    let b;
    try { b = await req.json(); } catch { return json({ error: "JSON inválido" }, 400); }
    const name = String(b.name || "").trim().slice(0, 20);
    const score = Number(b.score);
    const correct = Number(b.correct);
    // Cada acierto vale entre 500 y 1000 puntos: se valida que el total sea coherente
    const valid =
      name &&
      Number.isInteger(score) && Number.isInteger(correct) &&
      correct >= 0 && correct <= QUESTIONS &&
      score >= correct * 500 && score <= correct * 1000;
    if (!valid) return json({ error: "Datos inválidos" }, 400);

    // Un archivo por usuario: se guarda solo su mejor puntaje
    const key = encodeURIComponent(name.toLowerCase());
    const prev = await store.get(key, { type: "json" });
    if (!prev || score > prev.score) {
      await store.setJSON(key, { name, score, correct, date: Date.now() });
    }
    return json({ ok: true });
  }

  const { blobs } = await store.list();
  const all = await Promise.all(blobs.slice(0, 300).map((x) => store.get(x.key, { type: "json" })));
  const top = all
    .filter(Boolean)
    .sort((a, b) => b.score - a.score || a.date - b.date)
    .slice(0, 10)
    .map(({ name, score, correct }) => ({ name, score, correct }));
  return json(top);
};

export const config = { path: "/api/scores" };
